/*!
 * Copyright (c) 2013-Now 华夏erp All rights reserved.
 *
 * @author jishenghua
 * @version 2019-09-14
 */
(function (a) {
    window.js = window.js || {};
    js.i18n = a.extend({}, js.i18n, {
        "tabpanel.newTabPage": "新页签",
        "loading.message": "正在加载，请稍候...",
        "loading.submitMessage": "正在提交，请稍候...",
        "showMessage.error": "失败,错误,未完成",
        "showMessage.success": "成功,完成",
        "showMessage.warning": "不能,不允许,必须,已存在,不需要,不正确"
    })
})(jQuery);